#include <stdio.h>

int main()
{
	int a = 5, b = 133, c;

	c = a + b;
	c = a - b;
	c = a * b;
	c = a / b;

	c = a & b;
	c = a | b;
	c = a ^ b;


}

