#include <stdio.h>

int main()
{
	int a = 5;
	int b = 10;

	printf("%d + %d = %d\n",a,b,a+b);
}

