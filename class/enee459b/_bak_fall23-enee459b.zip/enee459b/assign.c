#include <stdio.h>

int main()
{
	int a, b, c;

	a = 2;
	b = 5;
	c = a + b;

	printf("a = %d, b = %d, c = %d\n",a,b,c);
}

