Flappy Bird written in C++ for BASH.

You should install ncurses lib before compiling:
```bash
sudo apt install ncurses*
```
![0-png](https://raw.githubusercontent.com/Erableto/Flappy-Bird/master/img/0.png)

![1-png](https://raw.githubusercontent.com/Erableto/Flappy-Bird/master/img/1.png)

![2-png](https://raw.githubusercontent.com/Erableto/Flappy-Bird/master/img/2.png)

![3-png](https://raw.githubusercontent.com/Erableto/Flappy-Bird/master/img/3.png)

![4-png](https://raw.githubusercontent.com/Erableto/Flappy-Bird/master/img/4.png)
