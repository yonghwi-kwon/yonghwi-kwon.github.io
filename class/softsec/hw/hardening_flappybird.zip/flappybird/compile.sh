make
objdump -g -S flappybird > flappybird.S
