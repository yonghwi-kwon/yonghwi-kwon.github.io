sudo apt-get install libncurses5-dev 
