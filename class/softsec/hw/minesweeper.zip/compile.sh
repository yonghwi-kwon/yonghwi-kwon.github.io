gcc -o mine main.c functions.c
objdump -S mine > mine.S
